#ifndef __PUBLIC__BASIC_TYPES_H__
#define __PUBLIC__BASIC_TYPES_H__

/*PROTECTED REGION ID(public_basic_types_h) ENABLED START*/


    // This is a protected region as long as you keep the marks :-)
#include <rtems_osswr/leon3_types.h>

/*PROTECTED REGION END*/

#endif // __PUBLIC__BASIC_TYPES_H__

#ifndef FCDLocationH
#define FCDLocationH
class CDLocation{
	
	public:
	
	float latitude;

	float longitude;
	
	protected:
	
	private:
	
};
#endif

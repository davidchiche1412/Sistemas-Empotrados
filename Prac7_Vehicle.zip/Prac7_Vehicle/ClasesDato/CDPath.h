#ifndef FCDPathH
#define FCDPathH

#include <public/basic_types.h>
#include <public/cdlocation_iface_v1.h>


class CDPath{
	
	public:
	
	uint8_t pathSteps;

	CDLocation pathLocations[255];

	
	protected:
	
	private:
	
};
#endif
